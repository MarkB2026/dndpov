DNDPOV — Seven House Framework (Village of Barovia v4.09)

Open village_of_barovia.html in Microsoft Edge and click the "7 Houses" button at the upper left to view the existing house showcase.

seven_house_framework.js contains the exact existing architectural family list and house() building generator extracted from the village source. It is a reference extract, not a standalone JavaScript module: it depends on the Three.js scene, materials, geometry and helper functions earlier in village_of_barovia.html.

The seven families are:
1. Stone & thatch cottage
2. Fired-brick townhouse
3. Whitewashed timber house
4. Wooden merchant shop
5. Three-storey jettied house
6. Stone-and-timber inn
7. Double-gabled residence

No changes have been made to the existing village code.
