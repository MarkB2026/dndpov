// Seven reusable architectural families. All details are local to each building.
const architecturalFamilies=[
 'Stone & thatch cottage','Fired-brick townhouse','Whitewashed timber house',
 'Wooden merchant shop','Three-storey jettied house','Stone-and-timber inn',
 'Double-gabled residence'
];
const tileRust=roofMats[0],slate=slateRoof,straw=thatchRoof;
const mortar=mat('#8b7f69'),darkIron=mat('#2c2926'),amber=mat('#a88b5c'),windowDark=mat('#343c3b'),doorInset=mat('#302923');
function detailBox(x,y,z,w,h,d,m,roofPart=false){
 const o=cube(x,y,z,w,h,d,m);if(roofPart)roofMeshes.push(o);return o;
}
function detailBeam(a,b,w,m=darkWood){
 beamBetween(a,b,w,m);
}
function windowFront(x,y,z,style){
 const frame=style===1?stoneMat:darkWood;
 detailBox(x,y,z,.76,1.1,.11,windowDark);
 detailBox(x,y,z+.07,.56,.88,.08,glass);
 detailBox(x,y,z+.15,.09,.98,.1,frame);
 detailBox(x,y,z+.15,.72,.09,.11,frame);
 detailBox(x,y+.53,z+.06,.99,.12,.24,frame);
 detailBox(x,y-.57,z+.08,1.05,.13,.33,stoneMat);
 if(style%2===0){
  detailBox(x-.49,y,z+.10,.18,1.04,.13,darkWood);
  detailBox(x+.49,y,z+.10,.18,1.04,.13,darkWood);
 }
}
function pitchedRoof(x,z,W,D,H,rise,material,seed,tiles=false){
 const over=.36,front=z+D/2+over,back=z-D/2-over;
 for(const side of [-1,1]){
  const edge=side*(W/2+over);
  const verts=[x,H+rise,back,x+edge,H,back,x+edge,H,front,
               x,H+rise,back,x+edge,H,front,x,H+rise,front];
  const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.Float32BufferAttribute(verts,3));geo.computeVertexNormals();
  const roofMat=material.clone();roofMat.side=THREE.DoubleSide;
  const m=new THREE.Mesh(geo,roofMat);m.castShadow=true;m.receiveShadow=true;scene.add(m);roofMeshes.push(m);
  if(tiles){
   const rows=7,cols=9;
   for(let j=0;j<rows;j++)for(let k=0;k<cols;k++){
    const u=(j+.5)/rows,zz=back+(k+.5)/cols*(front-back);
    const tile=detailBox(x+side*u*(W/2+over),H+rise*(1-u)+.045,zz,W/(rows*2)*.95,.055,(front-back)/cols*.94,material,true);
    tile.rotation.z=side*Math.atan2(rise,W/2+over);
   }
  }
 }
 for(const dz of [-D/2,D/2]){
  const shape=new THREE.Shape();shape.moveTo(-W/2,0);shape.lineTo(W/2,0);shape.lineTo(0,rise);shape.closePath();
  const m=new THREE.Mesh(new THREE.ShapeGeometry(shape),wallMats[(seed*3)%wallMats.length]);m.material.side=THREE.DoubleSide;
  m.position.set(x,H,z+dz);scene.add(m);
  detailBeam([x-W/2,H,z+dz+.035],[x,H+rise,z+dz+.035],.13);
  detailBeam([x,H+rise,z+dz+.035],[x+W/2,H,z+dz+.035],.13);
 }
 detailBox(x,H+rise+.02,z,W*.07,.11,D+.7,darkWood,true);
}
const houseGroups=[];
let firstHouseSceneIndex=-1;

function house(px,py,w=30,d=28,seed=0){
 const firstChild=scene.children.length;
 if(firstHouseSceneIndex<0)firstHouseSceneIndex=firstChild;
 const [x,z]=xy(px,py),W=w/5,D=d/5,style=seed%7;
 const heights=[3.5,5.3,5.1,4.3,7.2,5.2,5.8],H=heights[style]+(seed%3)*.14;
 const front=z+D/2+.17,beam=seed%2?darkWood:lightWood;
 const materialIds=[9,0,9,2,9,9,3],wall=wallMats[materialIds[style]];
 const upper=style===3?wallMats[2]:style===5?wallMats[9]:style===1?wallMats[0]:wall;
 blocks.push({x,z,r:Math.max(W,D)*.48});
 // All families have substantial masonry footings, not a floating box.
 detailBox(x,.4,z,W+.18,.8,D+.18,foundationMats[seed%3]);
 detailBox(x,(H+.8)/2,z,W,H-.8,D,style===0?stoneMat:wall);
 if(style===5){ // Inn: stone ground floor, timber upper floor.
  detailBox(x,1.25,z,W+.06,2.5,D+.06,stoneMat);
  detailBox(x,(H+2.5)/2,z,W+.12,H-2.5,D+.12,upper);
 }
 if(style===4){ // Jettied three-storey house with two projecting floors.
  detailBox(x,3.35,z+.14,W+.5,2.45,D+.35,upper);
  detailBox(x,5.9,z+.25,W+.78,2.25,D+.55,wallMats[9]);
  for(const yy of [2.2,4.65])detailBox(x,yy,front+.16,W+.65,.23,.5,beam);
 }
 if(style===2||style===4||style===5||style===6){
  for(const dx of [-W/2+.15,-W/4,0,W/4,W/2-.15]){
   detailBox(x+dx,H*.64,front-.025,.14,H*.69,.16,beam);
  }
  for(const yy of [2.5,H-.18])detailBox(x,yy,front-.02,W,.15,.17,beam);
  for(const sx of [-1,1])detailBeam([x+sx*W*.43,2.58,front],[x+sx*W*.18,Math.min(H-.3,4.7),front],.12,beam);
 }
 if(style===3){ // Merchant shop: wide timber storefront, canopy and counter.
  detailBox(x,1.48,front,Math.min(2.3,W*.5),1.48,.13,wood);
  detailBox(x,2.35,front+.57,W*.75,.14,1.3,beam);
  detailBox(x,2.26,front+.98,W*.74,.12,.12,roofMats[seed%8],true);
  detailBox(x,1.18,front+.23,W*.6,.17,.62,wood);
 }
 if(style===1){ // Brick courses and stone lintels, deeper front pilasters.
  for(const dx of [-W*.44,W*.44])detailBox(x+dx,H*.53,front,.26,H*.87,.24,stoneMat);
  for(const yy of [2.35,H-.22])detailBox(x,yy,front,.12,.17,.1,stoneMat);
 }
 if(style===0){ // Stone cottage: buttresses and low wooden porch.
  for(const dx of [-W*.43,W*.43])detailBox(x+dx,1.08,front,.4,2.0,.4,stoneMat);
 }
 // Deep doorway, plank seams, lintel, doorstep, metal handle.
 detailBox(x,.94,front+.02,1.2,1.88,.20,doorInset);
 detailBox(x,.94,front+.16,1.04,1.78,.13,doorWood);
 for(const dx of [-.32,0,.32])detailBox(x+dx,.94,front+.25,.035,1.73,.07,beam);
 detailBox(x,1.91,front+.09,1.4,.19,.33,stoneMat);
 detailBox(x,.14,front+.52,1.6,.28,.9,stoneMat);
 detailBox(x+.34,1.0,front+.28,.09,.12,.07,darkIron);
 for(const sx of [-1,1])windowFront(x+sx*W*.30,Math.min(H-.85,2.0),front+.10,style);
 if(H>4.7)for(const sx of [-1,1])windowFront(x+sx*W*.29,H-1.05,front+.12,style);
 // Side-facing small upper windows for a lived-in streetscape.
 if(style===4||style===5){detailBox(x+W/2+.08,H-.9,z,.12,.83,.66,glass);}
 const kind=style===0?'thatch':style===2||style===4?'slate':'tile';
 pitchedRoof(x,z,W,D,H,style===0?1.35:1.75,kind==='thatch'?straw:kind==='slate'?slate:roofMats[(seed+1)%8],seed,style===1||style===6);
 if(style===6){ // Two small cross-gables give the residence a different silhouette.
  for(const sx of [-1,1])pitchedRoof(x+sx*W*.24,z+D*.17,W*.45,D*.55,H+.18,1.25,slate,seed+2,false);
 }
 if(style===5){ // Inn sign and heavy bracket.
  detailBox(x+W*.36,2.9,front+.43,.12,.12,.94,darkWood);
  detailBox(x+W*.36,2.35,front+.88,.75,.85,.09,wood);
 }
 if(seed%3===0){const chimney=detailBox(x+W*.25,H+.65,z-.55,.53,1.95,.57,stoneMat,true);detailBox(x+W*.25,H+1.7,z-.55,.7,.16,.72,stoneMat,true)}
 const houseObjects=scene.children.slice(firstChild);
 // Select which cardinal facade faces the nearest paved road.
 // House models are authored with their door on local +Z.
 const directions=[
  {dx:0,dz:1,angle:0},{dx:1,dz:0,angle:Math.PI/2},
  {dx:0,dz:-1,angle:Math.PI},{dx:-1,dz:0,angle:-Math.PI/2}
 ];
 const frontDist=Math.max(W,D)*.50+.35;
 let best=directions[0],bestScore=Infinity;
 for(const d of directions){
  const fx=x+d.dx*frontDist,fz=z+d.dz*frontDist;
  let distance=Infinity;
  for(const road of baroviaSegments){
   distance=Math.min(distance,Math.max(0,segmentDistance(fx,fz,road.a,road.b)-road.width/2));
  }
  if(plazaBounds)distance=Math.min(distance,Math.max(0,Math.hypot(fx-plazaBounds.x,fz-plazaBounds.z)-plazaBounds.r));
  if(distance<bestScore){bestScore=distance;best=d}
 }
 // Only rotate houses when a nearby road provides a meaningful direction.
 const facingAngle=bestScore<13?best.angle:0;
 if(facingAngle!==0){
  const c=Math.cos(facingAngle),sn=Math.sin(facingAngle);
  for(const obj of houseObjects){
   const dx=obj.position.x-x,dz=obj.position.z-z;
   obj.position.x=x+dx*c+dz*sn;
   obj.position.z=z-dx*sn+dz*c;
   obj.rotation.y+=facingAngle;
  }
 }
 houseGroups.push({x,z,objects:houseObjects,facingAngle});
}
